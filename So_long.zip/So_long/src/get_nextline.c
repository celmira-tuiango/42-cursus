/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_nextline.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ctuiango <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/16 11:04:23 by ctuiango          #+#    #+#             */
/*   Updated: 2024/09/16 11:05:48 by ctuiango         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

static void	extra(void)
{
	perror("Error\n");
	exit(1);
}

char	*get_nextline(char *str)
{
	int		bytes;
	int		fd;
	char	buffer[1025];
	char	*content;

	content = 0;
	fd = open(str, O_RDONLY);
	if (fd < 0)
		extra();
	bytes = read(fd, buffer, 1024);
	while (bytes > 0)
	{
		buffer[bytes] = '\0';
		content = alocate_space(content, buffer);
		bytes = read(fd, buffer, 1024);
	}
	close(fd);
	if (bytes < 0 || content == NULL)
	{
		free(content);
		exit(1);
	}
	return (content);
}
